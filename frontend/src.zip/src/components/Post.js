import React from 'react';

function Post({ post }) {
  return (
    <div className="post">
      <div className="post-header">
        <span className="post-author">{post.user.name}</span>
        <span className="post-date">{post.created_at}</span>
      </div>
      <div className="post-content">
        <p>{post.content}</p>
        {post.media && (
          <div className="post-media">
            {post.media.endsWith('.mp4') || post.media.endsWith('.webm') ? (
              <video controls>
                <source src={post.media} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            ) : (
              <img src={post.media} alt="Post Media" />
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Post;
