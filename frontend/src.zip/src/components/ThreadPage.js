import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import httpClient from './httpClient';
import './ThreadPage.css';



function ThreadPage() {
  const { threadId } = useParams();

  const [thread, setThread] = useState({});
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState('');

  useEffect(() => {
    async function fetchThreadData() {
      try {
        const response = await httpClient.get(`http://127.0.0.1:5000/thread/${threadId}`);

        if (response.data) {
          setThread(response.data.thread || {});
          setPosts(response.data.posts || []);
        } else {
          console.error('Error fetching thread data');
        }
      } catch (error) {
        console.error('Error fetching thread data:', error);
      }
    }

    fetchThreadData();
  }, [threadId]);

  const addPost = async () => {
    // Check if the newPost field is empty
    if (!newPost.trim()) {
      console.error('Post content is empty');
      return; // Return early if content is empty
    }

    const requestData = {
      content: newPost,
    };

    try {
      const response = await httpClient.post(`http://127.0.0.1:5000/add_post/${threadId}`, requestData);

      const newPostData = response.data;
      setPosts((prevPosts) => [...prevPosts, newPostData]);
      setNewPost('');
    } catch (error) {
      console.error('Error adding post:', error);
    }
  };

  return (
    <div className='threadpage'>
      <h2>{thread.title}</h2>
      <div className="post-list">
        {posts.map((post) => (
          <div
            key={post.id}
            className={`post-card ${post.user === 'Current User' ? 'sent-by-user' : 'sent-by-others'}`}
          >
            <p className="post-content">{post.content}</p>
            <div className="post-meta">
              <p className="user-name">{post.user}</p>
              <p className="timestamp">{post.timestamp}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="new-post-form">
        <h2>Add New Post</h2>
        <textarea
          value={newPost}
          onChange={(e) => setNewPost(e.target.value)}
          placeholder="Enter your post"
        />
        <button onClick={addPost}>Add Post</button>
      </div>
    </div>
  );
}


export default ThreadPage;
