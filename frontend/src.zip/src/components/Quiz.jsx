import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  Button,
  Select,
  MenuItem,
} from "@mui/material";
import httpClient from "./httpClient";

const Quiz = () => {
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState("");
  const [score, setScore] = useState("");
  const [comment, setComment] = useState("");
  const [courseUnit, setCourseUnit] = useState("");
  const [topic, setTopic] = useState("");
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [user, setUser] = useState('');

  useEffect(() => {
    const fetchEnrolledCourses = async () => {
      try {
        const kresponse = await httpClient.get("http://127.0.0.1:5000/@me");
        setUser(kresponse.data);
        const response = await httpClient.get(
          `http://127.0.0.1:5000/enrolled_courses/${user.id}`
        );
        setEnrolledCourses(response.data.enrolled_courses);
      } catch (error) {
        console.error("Error fetching enrolled courses:", error);
      }
    };

    fetchEnrolledCourses();
  }, [user.id]);

  const handleSubmitForm = async () => {
    try {
      const response = await httpClient.post(
        "http://127.0.0.1:5000/generate_quiz_question",
        {
          courseUnit,
          topic,
        }
      );

      const { question_text, options } = response.data;
      setQuestion(question_text);
      setOptions(options);
      setSelectedOption("");
      setScore("");
      setComment("");
    } catch (error) {
      console.error("Error generating quiz question:", error);
    }
  };

  const handleSubmitAnswer = async () => {
    try {
      const response = await httpClient.post(
        "http://127.0.0.1:5000/grade_quiz_answer",
        {
          question: question,
          topic: topic,
          options: options,
          answer: selectedOption,
          courseUnit: courseUnit,
        }
      );

      setScore(response.data.score);
      setComment(response.data.comment);
    } catch (error) {
      console.error("Error grading answer:", error);
    }
  };

  return (
    <Box p={2}>
      <Typography variant="h4">Quiz</Typography>
      <Box mt={2}>
        <FormControl>
          <Select
            label="Course Unit"
            value={courseUnit}
            onChange={(e) => setCourseUnit(e.target.value)}
          >
            {enrolledCourses.map((course) => (
              <MenuItem key={course.id} value={course.name}>
                {course.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        {courseUnit && (
          <FormControl>
            <Select
              label="Topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
            >
              {enrolledCourses
                .find((course) => course.name === courseUnit)
                .topics.map((t) => (
                  <MenuItem key={t} value={t}>
                    {t}
                  </MenuItem>
                ))}
            </Select>
          </FormControl>
        )}
        <Button
          variant="contained"
          color="primary"
          onClick={handleSubmitForm}
        >
          Submit
        </Button>
      </Box>
      {question && (
        <Box mt={2}>
          <Typography variant="h5">Question:</Typography>
          <Typography>{question}</Typography>
          <form>
            <FormControl component="fieldset">
              <RadioGroup
                aria-label="quiz-options"
                name="quiz-options"
                value={selectedOption}
                onChange={(e) => setSelectedOption(e.target.value)}
              >
                {options.map((option, index) => (
                  <FormControlLabel
                    key={index}
                    value={option}
                    control={<Radio />}
                    label={option}
                  />
                ))}
              </RadioGroup>
            </FormControl>
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmitAnswer}
            >
              Submit Answer
            </Button>
          </form>
        </Box>
      )}
      {score !== "" && comment && (
        <Box mt={2}>
          <Typography variant="h6">Score: {score}</Typography>
          <Typography variant="h6">Comment: {comment}</Typography>
        </Box>
      )}
    </Box>
  );
};

export default Quiz;
