import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  Select,
  MenuItem,
} from "@mui/material";
import httpClient from "./httpClient";

const QuestionBank = () => {
  const [courseUnit, setCourseUnit] = useState("");
  const [topic, setTopic] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [score, setScore] = useState("");
  const [comment, setComment] = useState("");
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [user, setUser] = useState('');
  

  useEffect(() => {
    const fetchEnrolledCourses = async () => {
      try {
        const kresponse = await httpClient.get("http://127.0.0.1:5000/@me");
        setUser(kresponse.data);
        const response = await httpClient.get(
          
          `http://127.0.0.1:5000/enrolled_courses/${user.id}`
        );
        setEnrolledCourses(response.data.enrolled_courses);
      } catch (error) {
        console.error("Error fetching enrolled courses:", error);
      }
    };

    fetchEnrolledCourses();
  }, [user.id]);

  const handleGenerateQuestion = async () => {
    try {
      const response = await httpClient.post(
        "http://127.0.0.1:5000/generate_question",
        {
          courseUnit,
          topic,
        }
      );

      setQuestion(response.data.question_text);
      setAnswer("");
      setScore("");
      setComment("");
    } catch (error) {
      console.error(error?.response?.data || error.message);
    }
  };

  const handleSubmitAnswer = async () => {
    try {
      const response = await httpClient.post(
        "http://127.0.0.1:5000/grade_answer",
        {
          question: question,
          answer: answer,
          courseUnit: courseUnit,
          topic: topic,
        }
      );

      setScore(response.data.score);
      setComment(response.data.comment);
    } catch (error) {
      console.error(error?.response?.data || error.message);
    }
  };

  return (
    <Box p={2}>
      <Typography variant="h4">Question Bank</Typography>
      <Box mt={2}>
        <Select
          label="Course Unit"
          value={courseUnit}
          onChange={(e) => setCourseUnit(e.target.value)}
        >
          {enrolledCourses.map((course) => (
            <MenuItem key={course.id} value={course.name}>
              {course.name}
            </MenuItem>
          ))}
        </Select>
        {courseUnit && (
          <Select
            label="Topic"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
          >
            {enrolledCourses
              .find((course) => course.name === courseUnit)
              .topics.map((t) => (
                <MenuItem key={t} value={t}>
                  {t}
                </MenuItem>
              ))}
          </Select>
        )}
        <Button variant="contained" color="primary" onClick={handleGenerateQuestion}>
          Generate Question
        </Button>
      </Box>
      {question && (
        <Box mt={2}>
          <Typography variant="h5">Question:</Typography>
          <Typography>{question}</Typography>
          <TextField
            label="Answer"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
          />
          <Button
            variant="contained"
            color="primary"
            onClick={handleSubmitAnswer}
          >
            Submit Answer
          </Button>
        </Box>
      )}
      {score !== "" && (
        <Box mt={2}>
          <Typography variant="h6">Score: {score}</Typography>
          <Typography>Comment: {comment}</Typography>
        </Box>
      )}
    </Box>
  );
};

export default QuestionBank;
