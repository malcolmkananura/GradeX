import React, { useState, useEffect } from 'react';
import { Box, Typography, TextField, Button, List, ListItem, ListItemText, IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import httpClient from './httpClient';

const ManageCourse = () => {
  const [courseUnits, setCourseUnits] = useState([]);
  const [selectedCourseUnit, setSelectedCourseUnit] = useState('');
  const [newTopic, setNewTopic] = useState('');
  const [topics, setTopics] = useState([]);
  const [user, setUser] = useState('');

  useEffect(() => {
    const fetchCourseUnits = async () => {
      try {
        const kresponse = await httpClient.get("http://127.0.0.1:5000/@me");
        setUser(kresponse.data);
        const response = await httpClient.get(`http://127.0.0.1:5000/lecturer/${user.id}/courses`);
        setCourseUnits(response.data.courses);
      } catch (error) {
        console.error('Error fetching course units:', error);
      }
    };

    fetchCourseUnits();
  }, [user.id]);

  const handleCourseUnitChange = async (courseUnitId) => {
    setSelectedCourseUnit(courseUnitId);
    try {
      const response = await httpClient.get(`http://127.0.0.1:5000/course/${courseUnitId}/topics`);
      setTopics(response.data.topics);
    } catch (error) {
      console.error('Error fetching topics:', error);
    }
  };

  const handleAddTopic = async () => {
    if (!newTopic) return;

    try {
      await httpClient.post('http://127.0.0.1:5000/create_topic', {
        course_unit_id: selectedCourseUnit,
        topic_name: newTopic,
      });

      console.log(selectedCourseUnit);

      setNewTopic('');
      handleCourseUnitChange(selectedCourseUnit);
    } catch (error) {
      console.error('Error adding topic:', error);
    }
  };

  const handleDeleteTopic = async (topicId) => {
    try {
      await httpClient.delete(`http://127.0.0.1:5000/delete_topic/${topicId}`);
      handleCourseUnitChange(selectedCourseUnit);
    } catch (error) {
      console.error('Error deleting topic:', error);
    }
  };

  const handleDeleteCourseUnit = async (courseUnitId) => {
    try {
      await httpClient.delete(`http://127.0.0.1:5000/delete_course_unit/${courseUnitId}`);
      setSelectedCourseUnit('');
      setTopics([]);
      const response = await httpClient.get(`http://127.0.0.1:5000/lecturer/${user.id}/courses`);
      setCourseUnits(response.data.courses);
    } catch (error) {
      console.error('Error deleting course unit:', error);
    }
  };

  return (
    <Box p={2}>
      <Typography variant="h4">Manage Course</Typography>
      <List>
        {courseUnits.map((course) => (
          <ListItem key={course.id}>
            <ListItemText primary={course.name} onClick={() => handleCourseUnitChange(course.id)} />
            <IconButton edge="end" aria-label="delete" onClick={handleDeleteCourseUnit}>
              <DeleteIcon />
            </IconButton>
          </ListItem>
        ))}
      </List>
      {selectedCourseUnit && (
        <Box mt={2}>
          <Typography variant="h5">Topics:</Typography>
          <List>
            {topics.map((topic) => (
              <ListItem key={topic.id}>
                <ListItemText primary={topic.name} />
                <IconButton edge="end" aria-label="delete" onClick={() => handleDeleteTopic(topic.id)}>
                  <DeleteIcon />
                </IconButton>
              </ListItem>
            ))}
            <ListItem>
              <TextField
                label="New Topic"
                variant="outlined"
                value={newTopic}
                onChange={(e) => setNewTopic(e.target.value)}
              />
              <IconButton edge="end" aria-label="add" onClick={handleAddTopic}>
                <AddIcon />
              </IconButton>
            </ListItem>
          </List>
        </Box>
      )}
    </Box>
  );
};

export default ManageCourse;
