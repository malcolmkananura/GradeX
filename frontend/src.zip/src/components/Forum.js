import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import CategoryList from './CategoryList';
import httpClient from './httpClient';

function Forum() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const response = await httpClient.get("http://127.0.0.1:5000/get_categories");
        setCategories(response.data);
      } catch (error) {
        console.log("Not authenticated");
      }
    })();
  }, []);

  return (
    <div>
      <h1>Forum</h1>
      <CategoryList categories={categories} />
      {/* ...other forum content */}
    </div>
  );
}

export default Forum;
