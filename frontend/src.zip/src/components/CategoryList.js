import React from 'react';
import { Link } from 'react-router-dom';
import './CategoryList.css'; // Import your CSS file

function CategoryList({ categories }) {
  return (
    <div className="category-list">
      <h2>Categories</h2>
      <ul className='cat-comp'>
        {categories.map((category, index) => (
          <li key={category.id}>
            <Link to={`category/${category.id}`} className={`category-card color-${index % 4}`}>
              {category.name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CategoryList;
