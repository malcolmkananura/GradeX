import React from 'react'

const FAQ = () => {
  return (
    <div>
      <h2>FAQ</h2>
    </div>
  )
}

export default FAQ
