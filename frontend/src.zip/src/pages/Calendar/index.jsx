import React from 'react'

const Calendar = () => {
  return (
    <div>
      <h2>CALENDAR</h2>
    </div>
  )
}

export default Calendar
