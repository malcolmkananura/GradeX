import React from 'react'

const CourseUnits = () => {
  return (
    <div>
      <h2>COURSE UNITS</h2>
    </div>
  )
}

export default CourseUnits
