import React from "react";

const question_bank = () => (
    <div>
        Question Bank
    </div>
);

export default question_bank;