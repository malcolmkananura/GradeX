import React from 'react'

const Deadlines = () => {
  return (
    <div>
      <h2>DEADLINES</h2>
    </div>
  )
}

export default Deadlines
