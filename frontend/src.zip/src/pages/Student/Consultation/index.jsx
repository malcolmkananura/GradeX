import React from 'react'

const Consultation = () => {
  return (
    <div>
      <h2>FEEDBACK</h2>
    </div>
  )
}

export default Consultation
