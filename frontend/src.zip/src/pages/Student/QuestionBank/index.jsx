import React from 'react'

const QuestionBank = () => {
  return (
    <div>
      <h2>QUESTION BANK</h2>
    </div>
  )
}

export default QuestionBank
