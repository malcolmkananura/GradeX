import React from 'react'

const QuickQuiz = () => {
  return (
    <div>
      <h2>QUICK QUIZ</h2>
    </div>
  )
}

export default QuickQuiz
