// import React from "react";
// import StuSidebar from "./Studentsidebar";
// import QuestionBank from "../../components/QuestionBank"; // Import the QuestionBank component from your desired file path

// const QuestionBankPage = () => {
//   return (
//     <div style={{ display: 'flex', height: '100vh' }}>
//       {/* <StuSidebar /> */}
//       <QuestionBank />
//     </div>
//   );
// };

// export default QuestionBankPage;
