import React from 'react'

const Course = () => {
  return (
    <div>
      <h2>COURSE</h2>
    </div>
  )
}

export default Course
