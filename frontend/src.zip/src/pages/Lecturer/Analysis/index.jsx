import React from 'react'

const Analysis = () => {
  return (
    <div>
      <h2>ANALYSIS</h2>
    </div>
  )
}

export default Analysis
