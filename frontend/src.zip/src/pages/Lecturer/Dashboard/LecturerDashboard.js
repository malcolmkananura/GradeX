import React, { useState, useEffect } from 'react';
import { Box, Button, Typography } from "@mui/material";
import { tokens } from "../../../theme";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import Header from "../../../components/Header";
import httpClient from '../../../components/httpClient';

const LecturerDashboard = () => {
  const colors = tokens("light"); // Change the theme palette mode if needed

  const [topicsPerformance, setTopicsPerformance] = useState([]);
  

  useEffect(() => {
    fetchTopicsPerformance()
      .then((data) => {
        setTopicsPerformance(data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const fetchTopicsPerformance = async () => {
    try {
      const response = await httpClient.get("http://127.0.0.1:5000/get_all_topics_performance");
      return response.data;
    } catch (error) {
      throw error;
    }
  };



  return (
    <div>
      <Header title="LECTURER DASHBOARD" subtitle="Welcome to your dashboard" />
      <h2>Academic Performance</h2>
      
      <div className="dashboard-container">
        {topicsPerformance.map((performance, index) => (
          <div className="rounded-card" key={index}>
            <h2>{performance.topic_name}</h2>
            <p>Course: {performance.course_unit_name}</p>
            <p>Average Quiz Performance: {performance.average_quiz_performance}</p>
            <p>Average Essay Performance: {performance.average_essay_performance}</p>
          </div>
        ))}
      </div>

      
    </div>
  );
}



export default LecturerDashboard;
