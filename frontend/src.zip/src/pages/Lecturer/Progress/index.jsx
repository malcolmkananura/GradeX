import React from 'react'

const Progress = () => {
  return (
    <div>
      <h2>PROGRESS</h2>
    </div>
  )
}

export default Progress
